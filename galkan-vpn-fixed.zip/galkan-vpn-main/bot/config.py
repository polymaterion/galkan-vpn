"""
Bot configuration loaded from ENV.
"""
import os
from typing import Optional
from pydantic_settings import BaseSettings


class BotSettings(BaseSettings):
    TELEGRAM_TOKEN: str
    BILLING_BASE_URL: str = "http://billing:8000"
    BILLING_SECRET_KEY: str = ""

    ADMIN_IDS: str = ""  # comma-separated

    CRYPTOPAY_TOKEN: str = ""
    CRYPTOPAY_NETWORK: str = "mainnet"

    # Display-only — the actual trial length lives in the trial Plan row
    # (billing/seeds/seed.py reads TRIAL_DURATION_DAYS at seed time to set
    # Plan.duration_days). Keep this in sync with that same env var so the
    # "N-day trial" message the bot shows matches what's actually granted.
    TRIAL_DURATION_DAYS: int = 3

    SUPPORT_LINK: str = "https://t.me/support"
    AMNEZIA_DOWNLOAD_LINK: str = "https://amnezia.org/downloads"
    AMNEZIA_INSTRUCTION_LINK: str = "https://docs.amnezia.org/documentation/instructions/connect-via-text-key"

    # Manat (manual bank transfer) payments. MANAT_AGENTS lists who receives
    # the notification when a user requests to pay by manat — every agent
    # gets the same notification and any of them may confirm/reject it
    # (first to act wins; see BillingService.confirm_manat_request).
    # MANAT_AGENT_PHONES maps each agent's telegram_id to the phone number
    # shown to the PAYING USER (not the agent) so they know where to send
    # the transfer. Format: "id1:phone1,id2:phone2". An agent listed in
    # MANAT_AGENTS without a matching phone here is a configuration mistake
    # — parsed independently so it doesn't break parsing for other agents,
    # but that agent will never be selected to show a phone number for.
    MANAT_AGENTS: str = ""  # comma-separated telegram IDs
    MANAT_AGENT_PHONES: str = ""  # "id:phone,id:phone"

    @property
    def manat_agent_ids(self) -> list[int]:
        return [int(x.strip()) for x in self.MANAT_AGENTS.split(",") if x.strip()]

    @property
    def manat_agent_phones(self) -> dict[int, str]:
        phones: dict[int, str] = {}
        for pair in self.MANAT_AGENT_PHONES.split(","):
            pair = pair.strip()
            if not pair:
                continue
            if ":" not in pair:
                continue  # malformed entry — skip rather than crash the bot on startup
            agent_id_str, phone = pair.split(":", 1)
            try:
                phones[int(agent_id_str.strip())] = phone.strip()
            except ValueError:
                continue
        return phones

    @property
    def admin_ids_list(self) -> list[int]:
        return [int(x.strip()) for x in self.ADMIN_IDS.split(",") if x.strip()]

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = BotSettings()
