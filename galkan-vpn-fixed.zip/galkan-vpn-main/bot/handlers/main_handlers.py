"""Customer-facing Telegram screens.

The bot keeps one UI message per conversation. Callback handlers push a
screen into the FSM navigation stack and render it by editing that message.
The only intentional extra Telegram messages are payment invoices and QR
images, both of which Telegram requires to be separate message types.
"""
from __future__ import annotations

import html
import logging
from typing import Any

import httpx
from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
    SuccessfulPayment,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot import navigation
from bot.billing_client import billing_client
from bot.config import settings
from bot.keyboards.keyboards import (
    back_keyboard,
    check_usdt_payment,
    config_ready_keyboard,
    device_card_keyboard,
    devices_keyboard,
    download_vpn_keyboard,
    info_keyboard,
    invoice_keyboard,
    language_picker,
    main_menu,
    payment_method_menu,
    tariff_select_keyboard,
)
from bot.locales import t
from bot.payments.crypto_pay import crypto_pay
from bot.utils import generate_qr

logger = logging.getLogger(__name__)
router = Router()

STATUS_EMOJI = {
    "active": "✅",
    "expired": "❌",
    "pending_provisioning": "⏳",
    "error": "⚠️",
    "disabled": "🔒",
    "pending_payment": "💸",
}


async def _edit_view(
    message: Message,
    state: FSMContext,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
    **kwargs: Any,
) -> None:
    try:
        await message.edit_text(text, reply_markup=reply_markup, **kwargs)
    except TelegramBadRequest as exc:
        # Telegram returns this for a repeated tap on an already rendered
        # screen. It is safe to acknowledge and keep the current view.
        if "message is not modified" not in str(exc).lower():
            raise
    await navigation.set_ui_message(state, message.message_id)


async def _edit_ui_message(
    bot: Bot,
    chat_id: int,
    state: FSMContext,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
    **kwargs: Any,
) -> bool:
    message_id = await navigation.get_ui_message_id(state)
    if not message_id:
        return False
    try:
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            reply_markup=reply_markup,
            **kwargs,
        )
        return True
    except TelegramBadRequest as exc:
        if "message is not modified" in str(exc).lower():
            return True
        logger.warning("Unable to edit navigation message %s: %s", message_id, exc)
        return False


async def _main_view(lang: str) -> tuple[str, InlineKeyboardMarkup]:
    return t("welcome", lang), main_menu(lang)


async def _devices_view(
    telegram_id: int, lang: str
) -> tuple[str, InlineKeyboardMarkup]:
    try:
        devices = await billing_client.get_devices(telegram_id)
    except Exception as exc:
        logger.error("get_devices failed: %s", exc)
        devices = []

    if not devices:
        return t("devices_empty", lang), back_keyboard(lang)

    lines = [t("devices_title", lang), ""]
    for number, device in enumerate(devices, start=1):
        status = t(f"status_{device['status']}", lang)
        expires = (device.get("expires_at") or "")[:10] or t("unknown_expiry", lang)
        emoji = STATUS_EMOJI.get(device["status"], "❔")
        lines.append(
            t(
                "device_line",
                lang,
                emoji=emoji,
                n=number,
                status=status,
                expires=expires,
            )
        )
    return "\n".join(lines), devices_keyboard(lang, devices)


async def _device_view(
    telegram_id: int, lang: str, subscription_id: int
) -> tuple[str, InlineKeyboardMarkup | None]:
    try:
        devices = await billing_client.get_devices(telegram_id)
    except Exception as exc:
        logger.error("get_devices failed: %s", exc)
        devices = []
    device_number = next(
        (number for number, item in enumerate(devices, start=1) if item["id"] == subscription_id),
        None,
    )
    if device_number is None:
        return t("no_active_device", lang), back_keyboard(lang)

    device = devices[device_number - 1]
    status = t(f"status_{device['status']}", lang)
    expires = (device.get("expires_at") or "")[:10] or t("unknown_expiry", lang)
    text = t(
        "device_card",
        lang,
        n=device_number,
        status=status,
        expires=expires,
    )
    return text, device_card_keyboard(lang, device, device_number)


async def _tariff_select_view(
    lang: str, mode: str, target_id: int | None = None
) -> tuple[str, InlineKeyboardMarkup]:
    try:
        plans = await billing_client.get_plans()
    except Exception as exc:
        logger.error("get_plans failed: %s", exc)
        plans = []
    if not plans:
        return t("plan_unavailable", lang), back_keyboard(lang)
    text = t("tariff_select_title", lang)
    return text, tariff_select_keyboard(lang, plans, mode, target_id)


async def _plan_view(
    lang: str, mode: str, plan_id: int, target_id: int | None = None
) -> tuple[str, InlineKeyboardMarkup]:
    try:
        plans = await billing_client.get_plans()
        plan = next((p for p in plans if p["id"] == plan_id), None)
    except Exception as exc:
        logger.error("get_plans failed: %s", exc)
        plan = None
    if not plan:
        return t("plan_unavailable", lang), back_keyboard(lang)

    if mode == "renew":
        number = target_id or 0
        # The number is only cosmetic; the subscription id remains the source
        # of truth for the payment payload.
        text = t(
            "renew_card",
            lang,
            n=number,
            duration_days=plan["duration_days"],
            price_stars=plan["price_stars"],
            price_usdt=plan["price_usdt"],
            price_manat=plan["price_manat"],
        )
    else:
        text = t(
            "plan_card",
            lang,
            name=t("plan_name_text", lang, duration_days=plan["duration_days"]),
            description=t("plan_description_text", lang, duration_days=plan["duration_days"]),
            duration_days=plan["duration_days"],
            price_stars=plan["price_stars"],
            price_usdt=plan["price_usdt"],
            price_manat=plan["price_manat"],
        )
    return text, payment_method_menu(lang, plan_id, mode, target_id)


async def _resolve_screen(
    message: Message, state: FSMContext, lang: str, entry: dict[str, Any]
) -> tuple[str, InlineKeyboardMarkup | None]:
    screen = entry.get("screen", "main")
    params = entry.get("params", {})
    if screen == "main":
        text, markup = await _main_view(lang)
    elif screen == "devices":
        text, markup = await _devices_view(message.chat.id, lang)
    elif screen == "device_card":
        text, markup = await _device_view(message.chat.id, lang, int(params["subscription_id"]))
    elif screen == "purchase_new":
        text, markup = await _tariff_select_view(lang, "new")
    elif screen == "renew":
        text, markup = await _tariff_select_view(lang, "renew", int(params["subscription_id"]))
    elif screen == "plan_confirm":
        text, markup = await _plan_view(
            lang,
            params["mode"],
            int(params["plan_id"]),
            params.get("target_id"),
        )
    elif screen == "support":
        text, markup = t("support_text", lang, support_link=settings.SUPPORT_LINK), back_keyboard(lang)
    elif screen == "download_vpn":
        text = t("download_vpn_text", lang)
        markup = download_vpn_keyboard(lang, settings.AMNEZIA_DOWNLOAD_LINK)
    elif screen == "info":
        text = t("info_text", lang)
        markup = info_keyboard(lang)
    elif screen == "language":
        text, markup = t("language_prompt", lang), language_picker(lang, include_back=True)
    elif screen == "config_ready":
        text = t("config_ready", lang, expires=params.get("expires") or t("unknown_expiry", lang))
        markup = config_ready_keyboard(
            lang, bool(params.get("config_url")), int(params["subscription_id"])
        )
    elif screen == "provisioning":
        text, markup = t("provisioning_pending", lang), back_keyboard(lang)
    else:
        text, markup = await _main_view(lang)
        await navigation.reset(state)
    return text, markup


async def _render_entry(
    message: Message, state: FSMContext, lang: str, entry: dict[str, Any]
) -> None:
    text, markup = await _resolve_screen(message, state, lang, entry)
    await _edit_view(message, state, text, markup, disable_web_page_preview=True)


async def _deliver_result(
    bot: Bot,
    chat_id: int,
    lang: str,
    state: FSMContext,
    result: dict,
    fallback_message: Message | None = None,
) -> None:
    config_url = result.get("config_url")
    sub_id = result["subscription_id"]
    expires = (result.get("expires_at") or "")[:10] or t("unknown_expiry", lang)
    if not config_url:
        await navigation.replace(state, "provisioning")
        text, markup = t("provisioning_pending", lang), back_keyboard(lang)
    else:
        await navigation.replace(
            state,
            "config_ready",
            subscription_id=sub_id,
            config_url=config_url,
            expires=expires,
        )
        text = t("config_ready", lang, expires=expires)
        markup = config_ready_keyboard(lang, True, sub_id)

    edited = await _edit_ui_message(bot, chat_id, state, text, markup, disable_web_page_preview=True)
    if edited or fallback_message is None:
        return
    await fallback_message.answer(text, reply_markup=markup, disable_web_page_preview=True)


async def _get_device_config_url(telegram_id: int, sub_id: int) -> str | None:
    try:
        devices = await billing_client.get_devices(telegram_id)
        device = next((item for item in devices if item["id"] == sub_id), None)
        return device.get("config_url") if device else None
    except Exception as exc:
        logger.warning("Failed to fetch device %s: %s", sub_id, exc)
        return None


async def _send_qr(bot: Bot, chat_id: int, lang: str, telegram_id: int, sub_id: int) -> None:
    config_url = await _get_device_config_url(telegram_id, sub_id)
    if not config_url:
        await bot.send_message(chat_id, t("qr_unavailable", lang))
        return
    try:
        await bot.send_photo(
            chat_id,
            photo=BufferedInputFile(generate_qr(config_url), filename="vpn_qr.png"),
            caption=t("qr_caption", lang),
        )
    except Exception as exc:
        logger.warning("QR generation failed: %s", exc)
        await bot.send_message(chat_id, t("qr_unavailable", lang))


async def _send_key(bot: Bot, chat_id: int, lang: str, telegram_id: int, sub_id: int) -> None:
    config_url = await _get_device_config_url(telegram_id, sub_id)
    if not config_url:
        await bot.send_message(chat_id, t("qr_unavailable", lang))
        return
    await bot.send_message(chat_id, t("config_key_message", lang, config_url=html.escape(config_url)))


PENDING_DEEP_LINK_KEY = "pending_deep_link"


async def _grant_trial_and_notify(bot: Bot, chat_id: int, telegram_id: int, lang: str, *, silent_if_used: bool = False) -> None:
    """
    Attempts to grant the free trial device and sends the user a message
    either way. Shared by the auto-grant-on-first-/start path and the
    trial deep-link path — both end up wanting the same "grant, then tell
    the user what happened" behavior.

    silent_if_used=True is for the auto-grant path: a brand-new user can
    never actually hit the 409 (they can't have used a trial before this
    exact moment), so getting one there would only mean a genuine bug —
    log it, but don't show a confusing "already used" message for
    something the user didn't do. silent_if_used=False (deep-link path) is
    the opposite: hitting 409 there is the expected, common case (someone
    tapping the link a second time) and the user should be told plainly.
    """
    try:
        await billing_client.grant_trial(telegram_id)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            if not silent_if_used:
                await bot.send_message(chat_id, t("trial_already_used", lang))
            else:
                logger.error(
                    "Trial 409 on auto-grant for brand-new user %s — should be impossible",
                    telegram_id,
                )
            return
        logger.error("grant_trial failed for %s: %s", telegram_id, exc)
        await bot.send_message(chat_id, t("trial_error", lang))
        return
    except Exception as exc:
        logger.error("grant_trial failed for %s: %s", telegram_id, exc)
        await bot.send_message(chat_id, t("trial_error", lang))
        return
    await bot.send_message(chat_id, t("trial_granted", lang, days=settings.TRIAL_DURATION_DAYS))


# --- Root and stack navigation ------------------------------------------------

@router.message(Command("start"))
async def cmd_start(msg: Message, state: FSMContext, lang: str, is_new_user: bool, command: CommandObject):
    deep_link = (command.args or "").strip()

    if not lang:
        # Language not chosen yet. Two distinct cases land here:
        #  - is_new_user=True: this really is the very first /start ever.
        #  - is_new_user=False: an existing user who never finished picking
        #    a language on some earlier /start. They *could* already have
        #    used the trial via some other path, so silent_if_used must
        #    reflect their real is_new_user, not be assumed True — stash it
        #    alongside the deep-link payload rather than hardcoding it in
        #    cb_set_language below.
        if deep_link == "trial":
            await state.update_data(**{PENDING_DEEP_LINK_KEY: deep_link, "pending_deep_link_is_new": is_new_user})
        await msg.answer(t("language_prompt"), reply_markup=language_picker())
        return

    await navigation.reset(state)
    text, markup = await _main_view(lang)
    ui_message = await msg.answer(text, reply_markup=markup)
    await navigation.set_ui_message(state, ui_message.message_id)

    if is_new_user:
        # New signups get the trial automatically — no link needed. Fires
        # after the main menu is already shown so the trial confirmation
        # reads as "welcome, and by the way" rather than blocking entry.
        await _grant_trial_and_notify(msg.bot, msg.chat.id, msg.from_user.id, lang, silent_if_used=True)
    elif deep_link == "trial":
        # Existing user following the trial link with a language already
        # on file (the /start=trial → language-not-chosen-yet case is
        # handled above via the pending-deep-link stash instead).
        await _grant_trial_and_notify(msg.bot, msg.chat.id, msg.from_user.id, lang, silent_if_used=False)


@router.callback_query(F.data == "start")
async def cb_start(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.reset(state)
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:back")
async def cb_back(cb: CallbackQuery, state: FSMContext, lang: str):
    entry = await navigation.back(state)
    if entry["screen"].startswith("admin_"):
        # Admin handlers use the same stack primitive; the admin root is the
        # only admin target needed when going one level back.
        #
        # Re-check admin status here even though every push onto an admin_*
        # screen already required it: an admin removed from ADMIN_IDS
        # mid-session still has that entry sitting in their FSM stack (it
        # isn't tied to the admin list and isn't invalidated when the config
        # changes), and an ordinary back-tap would otherwise render the
        # admin panel for them with no further gate.
        if cb.from_user.id not in settings.admin_ids_list:
            await navigation.reset(state, "main")
            text, markup = await _main_view(lang)
            await _edit_view(cb.message, state, text, markup)
            await cb.answer(t("adm_no_access", lang), show_alert=True)
            return

        from bot.keyboards.keyboards import admin_menu

        await _edit_view(cb.message, state, t("adm_panel_title", lang), admin_menu(lang))
    elif cb.message.invoice:
        # An invoice message is a distinct Telegram-rendered type; it can
        # never be turned into a normal text message via edit_text (Telegram
        # rejects that), so going back from it means deleting the invoice
        # and sending the previous screen as a new message instead.
        text, markup = await _resolve_screen(cb.message, state, lang, entry)
        try:
            await cb.message.delete()
        except TelegramBadRequest as exc:
            logger.info("Could not delete invoice message on back: %s", exc)
        sent = await cb.bot.send_message(
            cb.message.chat.id, text, reply_markup=markup, disable_web_page_preview=True
        )
        await navigation.set_ui_message(state, sent.message_id)
    else:
        await _render_entry(cb.message, state, lang, entry)
    await cb.answer()


@router.callback_query(F.data == "nav:language")
async def cb_language_menu(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "language")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data.startswith("lang:"))
async def cb_set_language(cb: CallbackQuery, state: FSMContext):
    new_lang = cb.data.split(":", 1)[1]
    try:
        await billing_client.set_user_language(cb.from_user.id, new_lang)
    except Exception as exc:
        logger.error("Failed to save language for %s: %s", cb.from_user.id, exc)
    await navigation.reset(state)
    await _render_entry(cb.message, state, new_lang, await navigation.current(state))
    await cb.answer(t("language_saved", new_lang))

    # Only present if cmd_start stashed it — i.e. this was the very first
    # /start=trial, before a language existed to notify in. An ordinary
    # language change from settings never has this key, so this is a no-op
    # for that path.
    data = await state.get_data()
    if data.get(PENDING_DEEP_LINK_KEY) == "trial":
        was_new = bool(data.get("pending_deep_link_is_new"))
        await state.update_data(**{PENDING_DEEP_LINK_KEY: None, "pending_deep_link_is_new": None})
        await _grant_trial_and_notify(
            cb.bot, cb.from_user.id, cb.from_user.id, new_lang, silent_if_used=was_new
        )


@router.callback_query(F.data == "nav:devices")
async def cb_devices(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "devices")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data.startswith("nav:device:"))
async def cb_device(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "device_card", subscription_id=int(cb.data.rsplit(":", 1)[1]))
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:buy_new")
async def cb_buy_new(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "purchase_new")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data.startswith("nav:renew:"))
async def cb_renew(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "renew", subscription_id=int(cb.data.rsplit(":", 1)[1]))
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data.startswith("nav:tariff:"))
async def cb_tariff_selected(cb: CallbackQuery, state: FSMContext, lang: str):
    _, _, plan_id_s, mode, target_s = cb.data.split(":")
    target_id = int(target_s) if int(target_s) != 0 else None
    await navigation.push(state, "plan_confirm", plan_id=int(plan_id_s), mode=mode, target_id=target_id)
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:support")
async def cb_support(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "support")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:download_vpn")
async def cb_download_vpn(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "download_vpn")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:info")
async def cb_info(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "info")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


# --- Payments -----------------------------------------------------------------

@router.callback_query(F.data.startswith("pay_stars:"))
async def cb_pay_stars(cb: CallbackQuery, bot: Bot, state: FSMContext, lang: str):
    _, mode, target, plan_id_s = cb.data.split(":")
    target_id = int(target) if target != "0" else 0
    plan_id = int(plan_id_s)
    try:
        plans = await billing_client.get_plans()
        plan = next((p for p in plans if p["id"] == plan_id), None)
    except Exception as exc:
        logger.error("get_plans failed: %s", exc)
        plan = None
    if not plan:
        await cb.answer(t("plan_load_error", lang), show_alert=True)
        return
    plan_name = t("plan_name_text", lang, duration_days=plan["duration_days"])

    # Replace the payment-method screen with the invoice: the invoice is
    # always a separate Telegram-rendered message (it can't be embedded
    # into a normal text message), so "one screen at a time" here means
    # deleting the previous bot message rather than editing it in place.
    # Deletion can fail (message too old, already gone, etc.) — that's not
    # fatal, we still want the invoice to go out either way.
    try:
        await cb.message.delete()
    except TelegramBadRequest as exc:
        logger.info("Could not delete pre-invoice message: %s", exc)

    await navigation.push(state, "invoice", mode=mode, target_id=target_id)
    await bot.send_invoice(
        chat_id=cb.from_user.id,
        title=plan_name,
        description=t("plan_description_text", lang, duration_days=plan["duration_days"]),
        payload=f"stars:{mode}:{target_id}:{plan['id']}",
        currency="XTR",
        prices=[LabeledPrice(label=plan_name, amount=plan["price_stars"])],
        provider_token="",
        reply_markup=invoice_keyboard(lang, plan["price_stars"]),
    )
    await cb.answer()


@router.pre_checkout_query()
async def pre_checkout(pq: PreCheckoutQuery):
    await pq.answer(ok=True)


@router.message(F.successful_payment)
async def on_successful_payment(msg: Message, state: FSMContext, lang: str):
    payment: SuccessfulPayment = msg.successful_payment
    parts = payment.invoice_payload.split(":")
    mode = parts[1] if len(parts) > 1 else "new"
    target = int(parts[2]) if len(parts) > 2 and parts[2] != "0" else None
    plan_id = int(parts[3]) if len(parts) > 3 else None
    action_key = "payment_processing_renew" if mode == "renew" else "payment_processing_new"
    await _edit_ui_message(
        msg.bot,
        msg.chat.id,
        state,
        t("payment_processing", lang, action=t(action_key, lang)),
        back_keyboard(lang),
    )
    try:
        result = await billing_client.handle_stars_payment(
            telegram_id=msg.from_user.id,
            username=msg.from_user.username,
            first_name=msg.from_user.first_name,
            last_name=msg.from_user.last_name,
            charge_id=payment.telegram_payment_charge_id,
            total_amount=payment.total_amount,
            plan_id=plan_id,
            mode=mode,
            target_subscription_id=target,
        )
    except Exception as exc:
        logger.error("Stars payment processing failed: %s", exc)
        await navigation.replace(state, "support")
        await _edit_ui_message(msg.bot, msg.chat.id, state, t("payment_error", lang), back_keyboard(lang))
        return
    await _deliver_result(msg.bot, msg.chat.id, lang, state, result, msg)


@router.callback_query(F.data.startswith("pay_usdt:"))
async def cb_pay_usdt(cb: CallbackQuery, state: FSMContext, lang: str):
    _, mode, target, plan_id_s = cb.data.split(":")
    target_id = int(target) if target != "0" else None
    plan_id = int(plan_id_s)
    try:
        plans = await billing_client.get_plans()
        plan = next((p for p in plans if p["id"] == plan_id), None)
    except Exception:
        plan = None
    if not plan or not settings.CRYPTOPAY_TOKEN:
        await cb.answer(t("usdt_unavailable", lang), show_alert=True)
        return
    try:
        invoice = await crypto_pay.create_invoice(
            amount=float(plan["price_usdt"]),
            asset="USDT",
            description=t("plan_name_text", lang, duration_days=plan["duration_days"]),
            payload=f"{cb.from_user.id}:{plan['id']}:{mode}:{target_id or 0}",
        )
    except Exception as exc:
        logger.error("CryptoPay invoice creation failed: %s", exc)
        await cb.answer(t("usdt_invoice_error", lang), show_alert=True)
        return
    await navigation.push(state, "payment_usdt", invoice_id=invoice.get("invoice_id"), mode=mode, target_id=target_id)
    await _edit_view(
        cb.message,
        state,
        t("usdt_invoice_card", lang, amount=plan["price_usdt"], pay_url=invoice.get("pay_url", "")),
        check_usdt_payment(lang, str(invoice.get("invoice_id")), mode, target_id),
        disable_web_page_preview=True,
    )
    await cb.answer()


@router.callback_query(F.data.startswith("check_usdt:"))
async def cb_check_usdt(cb: CallbackQuery, state: FSMContext, lang: str):
    _, invoice_id_s, mode, target_s = cb.data.split(":")
    invoice_id = int(invoice_id_s)
    target_id = int(target_s) if target_s != "0" else None
    try:
        paid = await crypto_pay.is_paid(invoice_id)
    except Exception as exc:
        logger.error("CryptoPay check failed: %s", exc)
        await cb.answer(t("usdt_check_error", lang), show_alert=True)
        return
    if not paid:
        await cb.answer(t("usdt_not_paid_yet", lang), show_alert=True)
        return
    try:
        invoice = await crypto_pay.get_invoice(invoice_id)
    except Exception:
        invoice = {}
    parts = (invoice or {}).get("payload", "").split(":")
    plan_id = int(parts[1]) if len(parts) > 1 else None
    amount = (invoice or {}).get("amount")
    if amount is None and plan_id:
        try:
            plans = await billing_client.get_plans()
            plan = next((p for p in plans if p["id"] == plan_id), None)
            amount = plan["price_usdt"] if plan else None
        except Exception:
            amount = None
    if amount is None:
        logger.error("Could not resolve USDT amount for invoice %s (plan_id=%s)", invoice_id, plan_id)
        await cb.answer(t("usdt_check_error", lang), show_alert=True)
        return
    amount = float(amount)
    action_key = "payment_processing_renew" if mode == "renew" else "payment_processing_new"
    await _edit_view(cb.message, state, t("usdt_confirmed", lang, action=t(action_key, lang)), back_keyboard(lang))
    try:
        result = await billing_client.handle_usdt_payment(
            telegram_id=cb.from_user.id,
            username=cb.from_user.username,
            first_name=cb.from_user.first_name,
            last_name=cb.from_user.last_name,
            invoice_id=str(invoice_id),
            amount=amount,
            plan_id=plan_id,
            mode=mode,
            target_subscription_id=target_id,
        )
    except Exception as exc:
        logger.error("USDT activation failed: %s", exc)
        await navigation.replace(state, "support")
        await _edit_view(cb.message, state, t("usdt_activation_error", lang), back_keyboard(lang))
        await cb.answer()
        return
    await _deliver_result(cb.bot, cb.from_user.id, lang, state, result, cb.message)
    await cb.answer()


@router.callback_query(F.data.startswith("show_qr:"))
async def cb_show_qr(cb: CallbackQuery, lang: str):
    await _send_qr(cb.bot, cb.from_user.id, lang, cb.from_user.id, int(cb.data.split(":")[1]))
    await cb.answer()


# --- Manat (manual bank transfer via agent) ---------------------------------

@router.callback_query(F.data.startswith("pay_manat:"))
async def cb_pay_manat(cb: CallbackQuery, bot: Bot, state: FSMContext, lang: str):
    _, mode, target, plan_id_s = cb.data.split(":")
    target_id = int(target) if target != "0" else None
    plan_id = int(plan_id_s)

    agent_ids = settings.manat_agent_ids
    agent_phones = settings.manat_agent_phones
    # The phone shown to the payer is deterministically the first configured
    # agent's — not whichever agent ends up confirming (that's decided later
    # by whoever taps first; see BillingService.confirm_manat_request). This
    # keeps the shown number stable and predictable across repeated views of
    # the same request, rather than picking at random.
    shown_phone = next((agent_phones[aid] for aid in agent_ids if aid in agent_phones), None)
    if not agent_ids or not shown_phone:
        logger.error("Manat payment requested but no agents/phones configured")
        await cb.answer(t("manat_unavailable", lang), show_alert=True)
        return

    try:
        request = await billing_client.create_manat_request(
            telegram_id=cb.from_user.id,
            username=cb.from_user.username,
            first_name=cb.from_user.first_name,
            last_name=cb.from_user.last_name,
            plan_id=plan_id,
            agent_phone_shown=shown_phone,
            mode=mode,
            target_subscription_id=target_id,
        )
    except Exception as exc:
        logger.error("create_manat_request failed: %s", exc)
        await cb.answer(t("manat_request_error", lang), show_alert=True)
        return

    request_id = request["request_id"]
    amount = request["amount_manat"]
    phone = request["agent_phone_shown"]

    await navigation.push(state, "manat_pending", request_id=request_id)
    await _edit_view(
        cb.message,
        state,
        t("manat_request_created", lang, amount=amount, phone=phone),
        back_keyboard(lang),
    )
    await cb.answer()

    # ALL agents get the same notification and any of them may act on it —
    # first to tap Confirm/Reject wins (see BillingService.confirm_manat_request
    # for the race protection). Sending to an agent who has blocked the bot
    # or no longer exists must not stop the others from being notified.
    payer_label = f"@{cb.from_user.username}" if cb.from_user.username else str(cb.from_user.id)
    notify_kb = InlineKeyboardBuilder()
    notify_kb.row(
        InlineKeyboardButton(text=t("manat_agent_confirm_btn", lang), callback_data=f"manat_confirm:{request_id}"),
        InlineKeyboardButton(text=t("manat_agent_reject_btn", lang), callback_data=f"manat_reject:{request_id}"),
    )
    for agent_id in agent_ids:
        try:
            await bot.send_message(
                agent_id,
                t(
                    "manat_agent_notification",
                    lang,
                    request_id=request_id,
                    payer=payer_label,
                    amount=amount,
                    phone=phone,
                ),
                reply_markup=notify_kb.as_markup(),
            )
        except Exception as exc:
            logger.warning("Failed to notify manat agent %s: %s", agent_id, exc)


async def _resolve_manat_action(
    cb: CallbackQuery, bot: Bot, lang: str, action: str
) -> None:
    request_id = int(cb.data.split(":")[1])
    try:
        if action == "confirm":
            result = await billing_client.confirm_manat_request(request_id, agent_id=cb.from_user.id)
        else:
            result = await billing_client.reject_manat_request(request_id, agent_id=cb.from_user.id)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            await cb.message.edit_text(t("manat_already_resolved", lang))
            await cb.answer()
            return
        logger.error("manat %s failed for request %s: %s", action, request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return
    except Exception as exc:
        logger.error("manat %s failed for request %s: %s", action, request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    if action == "confirm":
        await cb.message.edit_text(t("manat_confirmed_by_you", lang, request_id=request_id))
    else:
        await cb.message.edit_text(t("manat_rejected_by_you", lang, request_id=request_id))
    await cb.answer()

    if action != "confirm":
        return  # rejected — nothing provisioned, nothing to tell the payer beyond what they already know

    # Tell the payer directly — this handler runs in the AGENT's chat/FSM
    # session, which has no access to the payer's FSMContext (different
    # Telegram user entirely), so the payer's existing navigation message
    # can't be edited in place the way _deliver_result does for same-user
    # flows. A fresh message is the only option here, and is sufficient:
    # the payer's "My subscriptions" screen reflects the real state on next
    # open regardless.
    payer_telegram_id = result.get("telegram_id")
    if not payer_telegram_id:
        logger.warning("confirm_manat_request response missing telegram_id, cannot notify payer")
        return
    expires = (result.get("expires_at") or "")[:10] or t("unknown_expiry", lang)
    try:
        if result.get("config_url"):
            await bot.send_message(
                payer_telegram_id,
                t("config_ready", lang, expires=expires),
                reply_markup=config_ready_keyboard(lang, True, result["subscription_id"]),
            )
        else:
            await bot.send_message(payer_telegram_id, t("provisioning_pending", lang))
    except Exception as exc:
        logger.warning("Failed to notify manat payer %s: %s", payer_telegram_id, exc)


@router.callback_query(F.data.startswith("manat_confirm:"))
async def cb_manat_agent_confirm(cb: CallbackQuery, bot: Bot, lang: str):
    if cb.from_user.id not in settings.manat_agent_ids:
        await cb.answer(t("manat_not_an_agent", lang), show_alert=True)
        return
    await _resolve_manat_action(cb, bot, lang, "confirm")


@router.callback_query(F.data.startswith("manat_reject:"))
async def cb_manat_agent_reject(cb: CallbackQuery, bot: Bot, lang: str):
    if cb.from_user.id not in settings.manat_agent_ids:
        await cb.answer(t("manat_not_an_agent", lang), show_alert=True)
        return
    await _resolve_manat_action(cb, bot, lang, "reject")


@router.callback_query(F.data.startswith("show_key:"))
async def cb_show_key(cb: CallbackQuery, lang: str):
    await _send_key(cb.bot, cb.from_user.id, lang, cb.from_user.id, int(cb.data.split(":")[1]))
    await cb.answer()
