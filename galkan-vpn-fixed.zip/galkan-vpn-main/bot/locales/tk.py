"""
Turkmen (Türkmençe) strings.

NOTE: this translation was produced by Claude without a native-speaker
review. Standard modern Turkmen (Latin script) vocabulary was used
throughout, but for a real customer-facing product we'd recommend having a
native Turkmen speaker proofread this file before relying on it at scale —
especially the payment/legal-sensitive strings. Any key missing here (or
that fails to .format()) automatically falls back to the Russian string, so
a typo here never breaks the bot, just shows Russian for that one line.
"""

STRINGS: dict[str, str] = {
    "language_prompt": "🌐 Diliňizi saýlaň / Выберите язык:",
    "btn_lang_ru": "🇷🇺 Русский",
    "btn_lang_tk": "🇹🇲 Türkmençe",
    "language_saved": "Dil saklandy: Türkmençe ✅",

    "welcome": (
        "👋 <b>Galkan VPN</b>-a hoş geldiňiz!\n\n"
        "🛡 AmneziaWG esasynda howpsuz VPN — päsgelçilikleri yzsyz aşýar.\n\n"
        "Hereketi saýlaň:"
    ),
    "btn_my_subscriptions": "📱 Meniň abunalarym",
    "btn_buy_new": "➕ Abuna satyn almak",
    "btn_download_vpn": "⬇️ VPN ýüklemek",
    "btn_support": "💬 Goldaw",
    "btn_info": "ℹ️ Maglumat",
    "btn_language": "🌐 Dil",
    "btn_back": "◀️ Yza",
    "btn_back_to_menu": "◀️ Baş menýu",

    "devices_title": "📱 <b>Siziň abunalaryňyz</b>\n\nHer abuna — aýratyn tölenen VPN açary.",
    "devices_empty": (
        "Siziň entek abunaňyz ýok.\n\n"
        "Her abuna — bir telefonda/kompýuterde ulanyp boljak aýratyn VPN açary."
    ),
    "device_line": (
        "{emoji} <b>Abuna #{n}</b>\n"
        "Ýagdaýy: {status}\n"
        "Şu senä çenli hereket edýär: {expires}\n"
    ),
    "btn_device_connect": "🔑 #{n} birikdirmek",
    "btn_device_open": "📄 #{n} abunany açmak",
    "btn_device_qr": "📱 #{n} QR",
    "btn_device_renew": "🔄 #{n} abunany uzaltmak",
    "status_active": "✅ Işjeň",
    "status_expired": "❌ Möhleti geçen",
    "status_pending_provisioning": "⏳ Döredilýär",
    "status_error": "⚠️ Ýalňyşlyk",
    "status_disabled": "🔒 Öçürilen",
    "status_pending_payment": "💳 Töleg garaşylýar",
    "unknown_expiry": "näbelli",
    "device_card": (
        "📄 <b>Abuna #{n}</b>\n\n"
        "Ýagdaýy: {status}\n"
        "Şu senä çenli hereket edýär: {expires}\n\n"
        "Hereketi saýlaň:"
    ),

    "tariff_select_title": "💎 <b>Abunanyň möhletini saýlaň:</b>",
    "btn_tariff_option": "{duration_days} gün — {price_stars}⭐",

    "plan_name_text": "VPN — {duration_days} gün",
    "plan_description_text": "AmneziaWG protokoly esasynda {duration_days} günlük çäksiz VPN.",
    "plan_card": (
        "💎 <b>{name}</b>\n\n"
        "{description}\n\n"
        "⏱ Möhlet: <b>{duration_days} gün</b>\n"
        "⭐ Bahasy: <b>{price_stars} Telegram Stars</b>\n"
        "💵 ýa-da <b>${price_usdt} USDT</b>\n"
        "💰 ýa-da <b>{price_manat} TMT</b>\n\n"
        "Bu aýratyn abuna: bir töleg = bir enjam üçin bir VPN açary. Başga bir "
        "enjam üçin açar şol bir bahadan aýratyn töleg bilen resmileşdirilýär.\n\n"
        "Töleg usulyny saýlaň:"
    ),
    "renew_card": (
        "🔄 <b>#{n} abunany uzaltmak</b>\n\n"
        "⏱ Ýene {duration_days} gün\n"
        "⭐ Bahasy: <b>{price_stars} Telegram Stars</b>\n"
        "💵 ýa-da <b>${price_usdt} USDT</b>\n"
        "💰 ýa-da <b>{price_manat} TMT</b>\n\n"
        "Açar şol bir bolup galýar — diňe hereket möhleti uzaldylýar.\n\n"
        "Töleg usulyny saýlaň:"
    ),
    "btn_pay_stars": "⭐ Telegram Stars bilen tölemek",
    "btn_pay_usdt": "💎 USDT (Kripto) bilen tölemek",
    "btn_pay_manat": "💰 Manat bilen tölemek",
    "btn_invoice_pay": "Tölemek ⭐{price}",
    "plan_unavailable": "Tarifler wagtlaýyn elýeterli däl.",
    "plan_load_error": "Tarifi ýüklemekde ýalňyşlyk.",

    "payment_processing": "⏳ Töleg kabul edildi! {action}",
    "payment_processing_new": "Täze VPN açaryňyz döredilýär...",
    "payment_processing_renew": "Enjam uzaldylýar...",
    "payment_error": (
        "❗ Töleg geçdi, ýöne VPN elýeterliligini döretmekde ýalňyşlyk ýüze çykdy.\n"
        "Goldawa ýüz tutuň — hemme zady düzederis!"
    ),
    "provisioning_pending": (
        "⏳ VPN elýeterliligi döredilýär, bu birnäçe minut wagt alar.\n"
        "Taýyn bolanda habar alarsyňyz — «Meniň enjamlarym» bölümine serediň."
    ),

    "config_ready": (
        "✅ <b>Enjam taýyn!</b>\n"
        "⏳ Şu senä çenli hereket edýär: <b>{expires}</b>\n\n"
        "Açar aşakdaky düwme arkaly islendik wagt elýeterli."
    ),
    "btn_connect_amnezia": "🔑 Açary görkezmek",
    "btn_show_qr": "📱 QR-kody görkezmek",
    "qr_caption": "📷 Bu QR-kody AmneziaVPN programmasynda skanirläň",
    "qr_unavailable": "Konfigurasiýa elýeterli däl. Soňra synanyşyň.",
    "config_key_message": (
        "🔑 Birikdirmek üçin açaryňyz:\n"
        "<pre>{config_url}</pre>\n\n"
        "Ýokardaky blokda «Copy Code» basyň, soňra AmneziaVPN programmasynda "
        "«Konfigurasiýa goşmak» → «Buferden» arkaly ýerleşdiriň."
    ),

    "usdt_unavailable": "USDT tölegi wagtlaýyn elýeterli däl. Telegram Stars-y synanyşyň.",
    "usdt_invoice_error": "Hasap-faktura döretmekde ýalňyşlyk. Soňra synanyşyň.",
    "usdt_invoice_card": (
        "💎 <b>USDT tölegi</b>\n\n"
        "Möçberi: <b>${amount} USDT</b>\n\n"
        "👉 <a href='{pay_url}'>Tölege geçmek</a>\n\n"
        "Töleg edenizden soň ✅ düwmesine basyň"
    ),
    "btn_i_paid": "✅ Men töledim",
    "btn_cancel": "❌ Ýatyr",
    "usdt_check_error": "Tölegi barlamakda ýalňyşlyk. Soňra synanyşyň.",
    "usdt_not_paid_yet": "Töleg entek gelip gowuşmady. Bir minutdan soň synanyşyň.",
    "usdt_confirmed": "⏳ Töleg tassyklandy! {action}",
    "usdt_activation_error": "❗ Işjeňleşdirmekde ýalňyşlyk. Goldawa ýüz tutuň.",

    "support_text": "💬 <b>Goldaw</b>\n\nIslendik sorag boýunça: {support_link}",

    "download_vpn_text": (
        "⬇️ <b>AmneziaVPN ýüklemek</b>\n\n"
        "Aşakdaky düwme arkaly enjamyňyz üçin resmi programmany gurnaň."
    ),
    "btn_amnezia_download": "⬇️ AmneziaVPN ýüklemek",

    # PLACEHOLDER: production-a çykmazdan öň hakyky ulanyjy ylalaşygy /
    # gizlinlik syýasaty teksti bilen çalşyryň.
    "info_text": (
        "ℹ️ <b>Maglumat</b>\n\n"
        "Galkan VPN gullugynyň ulanyjy ylalaşygy we gizlinlik syýasaty şu ýerde "
        "ýerleşdiriler.\n\n"
        "Ulanyş şertleri barada goldawa ýüz tutuň."
    ),

    "no_active_device": "Işjeň enjam tapylmady.",

    # --- Admin panel ---
    "adm_access_denied": "⛔ Girmek gadagan.",
    "adm_no_access": "⛔ Elýeterlilik ýok.",
    "adm_panel_title": "🔧 <b>Administrator paneli</b>",
    "adm_btn_users": "👥 Ulanyjylar",
    "adm_btn_subs": "📋 Abunalar",
    "adm_btn_payments": "💰 Tölegler",
    "adm_btn_servers": "🖥 Serwerler",
    "adm_btn_back": "◀️ Administrator paneline",
    "adm_users_title": "👥 <b>Ulanyjylar</b> (jemi: {total})\n",
    "adm_subs_title": "📋 <b>Abunalar</b>\n",
    "adm_payments_title": "💰 <b>Tölegler</b>\n",
    "adm_servers_title": "🖥 <b>VPN serwerleri</b>\n",
    "adm_no_servers": "Serwer ýok",
    "adm_error": "Ýalňyşlyk: {error}",
    "adm_extend_usage": "Usage: /extend <sub_id> [days=30]",
    "adm_extend_success": "✅ #{sub_id} abunasy {days} güne uzaldyldy.",
    "adm_disable_usage": "Usage: /disable_sub <sub_id>",
    "adm_disable_success": "✅ #{sub_id} abunasy öçürildi.",
    "adm_reissue_usage": "Usage: /reissue_device <sub_id>",
    "adm_reissue_success": (
        "✅ #{sub_id} abunasynyň enjamy täzeden döredildi. Köne açar indi "
        "işlemeýär — täzesi ulanyjy üçin «Açary görkezmek» arkaly elýeterli."
    ),
    "adm_server_status_usage": "Usage: /server_status <server_id> <active|disabled>",
    "adm_server_status_success": "✅ #{server_id} serwer → {status}",
    "adm_add_server_usage": (
        "Usage: /add_server <name> <base_url> <api_key> [region] [weight] [max_clients] [protocol]\n"
        "Example: /add_server Server-DE http://1.2.3.4 <FASTIFY_API_KEY> DE 100 200 amneziawg2"
    ),
    "adm_add_server_success": "✅ #{id} «{name}» serweri goşuldy we işjeň (protokol: {protocol}).",
    "adm_generic_error": "❌ Ýalňyşlyk: {error}",

    # --- Trial (user-facing) ---
    "trial_granted": (
        "🎁 Size {days} günlük synag döwri berildi!\n\n"
        "Birikme açaryny almak üçin «Meniň enjamlarym» bölümini açyň."
    ),
    "trial_already_used": "Bu hasapda synag döwri eýýäm ulanyldy.",
    "trial_error": "Synag döwrüni bermek başartmady. Soňra synanyşyň ýa-da goldawa ýüz tutuň.",

    # --- Admin: trial link ---
    "adm_trial_link_message": (
        "🔗 Synag döwrüni birikdirmek üçin salgy:\n{link}\n\n"
        "Öň botu işledenler üçin hem işleýär."
    ),

    # --- Admin: broadcast ---
    "adm_broadcast_usage": (
        "Usage: ibermeli habara jogap hökmünde /broadcast ibersin "
        "(tekst, surat/wideo — islendik görnüşi).\n\n"
        "Baglanyşyk düwmeleri goşmak üçin komandadan soň her setirde bir düwme ýazyň:\n"
        "/broadcast\n"
        "Düwme teksti - https://example.com\n"
        "Ýene bir düwme - https://example.com\n\n"
        "Bir setirde birnäçe düwme « | » bilen aýrylýar:\n"
        "Düwme A - https://a.com | Düwme B - https://b.com"
    ),
    "adm_broadcast_no_reply": "Ibermeli habara jogap hökmünde bu komandany ibersin.",
    "adm_broadcast_bad_button": (
        "❌ {line_num}-nji setirdäki düwme dogry däl: «{line}»\n"
        "Format: Tekst - https://salgy"
    ),
    "adm_broadcast_confirm": "📢 Bu habar {count} ulanyja iberilsinmi?",
    "adm_broadcast_confirm_btn": "✅ Ibermek",
    "adm_broadcast_cancel_btn": "❌ Ýatyrmak",
    "adm_broadcast_cancelled": "Ibermek ýatyryldy.",
    "adm_broadcast_expired": (
        "⚠️ Bu tassyklama indi hakyky däl (mysal üçin, bot täzeden işledildi). "
        "/broadcast komandasy bilen täzeden başlaň."
    ),
    "adm_broadcast_started": "⏳ Ibermek başlady ({count} alyjy)...",
    "adm_broadcast_done": (
        "✅ Ibermek tamamlandy.\n"
        "Iberildi: {sent}\n"
        "Iberilmedi (boty petiklän ýaly): {failed}"
    ),

    # --- Manat (manual bank transfer via agent) ---
    "manat_unavailable": "Manat bilen töleg wagtlaýyn elýeterli däl. Başga töleg usulyny synanyşyň.",
    "manat_request_error": "Töleg üçin haýyş döretmek başartmady. Soňra synanyşyň.",
    "manat_request_created": (
        "💰 <b>{amount} TMT</b> möçberi şu belgä geçiriň:\n"
        "<code>{phone}</code>\n\n"
        "Geçirimden soň operatoryň tassyklamasyna garaşyň — operator töleg "
        "gelenini görenden soň awtomatik geler."
    ),
    "manat_action_error": "Haýyşy işlemekde ýalňyşlyk. Ýene synanyşyň.",
    "manat_already_resolved": "⚠️ Bu haýyş eýýäm başga operator tarapyndan işlenildi.",
    "manat_not_an_agent": "Bu hereket üçin ygtyýaryňyz ýok.",
    "manat_confirmed_by_you": "✅ #{request_id} haýyşy siz tarapyňyzdan tassyklandy. Abuna işjeňleşdirilýär.",
    "manat_rejected_by_you": "❌ #{request_id} haýyşy siz tarapyňyzdan ret edildi.",
    "manat_agent_notification": (
        "💰 <b>Manat bilen töleg üçin täze haýyş</b>\n\n"
        "Haýyş: #{request_id}\n"
        "Kimden: {payer}\n"
        "Möçberi: {amount} TMT\n"
        "Geçirmek üçin belgi: {phone}\n\n"
        "Geçirimiň gelenini barlaň we haýyşy tassyklaň ýa-da ret ediň."
    ),
    "manat_agent_confirm_btn": "✅ Tassyklamak",
    "manat_agent_reject_btn": "❌ Ret etmek",
}
