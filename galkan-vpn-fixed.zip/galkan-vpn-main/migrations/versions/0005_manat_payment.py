"""Add manat payment: Plan.price_manat, PaymentProvider.manat, manat_payment_requests table

Revision ID: 0005_manat_payment
Revises: 0004_plan_is_trial
Create Date: 2026-08-27
"""
from alembic import op
import sqlalchemy as sa

revision = "0005_manat_payment"
down_revision = "0004_plan_is_trial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "plans",
        sa.Column(
            "price_manat",
            sa.Numeric(14, 2),
            nullable=False,
            server_default="0",
        ),
    )

    # ALTER TYPE ... ADD VALUE cannot run inside the same transaction that
    # later reads/writes a row using the new value (Postgres makes a new
    # enum label visible only after the adding transaction commits) — not
    # an issue here since this migration only changes schema, never inserts
    # a payments row with provider='manat'. Safe to run inside Alembic's
    # normal per-migration transaction on Postgres 12+ (this project runs
    # 16, per docker-compose.yml).
    op.execute("ALTER TYPE paymentprovider ADD VALUE IF NOT EXISTS 'manat'")

    manat_request_status = sa.Enum(
        "pending", "confirmed", "rejected", "expired", name="manatrequeststatus"
    )
    manat_request_status.create(op.get_bind(), checkfirst=True)

    op.create_table(
        "manat_payment_requests",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("plan_id", sa.Integer(), sa.ForeignKey("plans.id"), nullable=False),
        sa.Column("mode", sa.String(length=16), nullable=False),
        sa.Column(
            "target_subscription_id",
            sa.Integer(),
            sa.ForeignKey("subscriptions.id"),
            nullable=True,
        ),
        sa.Column("amount_manat", sa.Numeric(14, 2), nullable=False),
        sa.Column("agent_phone_shown", sa.String(length=32), nullable=False),
        sa.Column("status", manat_request_status, nullable=False, server_default="pending"),
        sa.Column("resolved_by_agent_id", sa.BigInteger(), nullable=True),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("payment_id", sa.Integer(), sa.ForeignKey("payments.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            onupdate=sa.func.now(),
        ),
    )
    op.create_index(
        "ix_manat_payment_requests_user_id", "manat_payment_requests", ["user_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_manat_payment_requests_user_id", table_name="manat_payment_requests")
    op.drop_table("manat_payment_requests")
    sa.Enum(name="manatrequeststatus").drop(op.get_bind(), checkfirst=True)
    op.drop_column("plans", "price_manat")
    # Postgres has no ALTER TYPE ... DROP VALUE — removing an enum label
    # requires rebuilding the type (create new type, migrate column, drop
    # old type), which is a much larger and riskier operation than adding
    # one. Left as a no-op: a stray unused 'manat' label in the enum after
    # downgrade is harmless (nothing references it once the table using it
    # is gone) and this project's other migrations don't attempt this
    # either — see 0004's downgrade, which also doesn't reverse row data.
