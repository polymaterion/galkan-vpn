"""
Integration tests for billing FastAPI endpoints.
Uses test DB and mocked AmneziaClient.
"""
import os
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from unittest.mock import AsyncMock, patch

from api.main import app
from billing.database import AsyncSessionLocal, engine as _engine
from models import Base
import models.models  # noqa


# ---------------------------------------------------------------------------
# Override DB session in FastAPI dependency for tests
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture(autouse=True)
async def _billing_engine_schema():
    """
    These tests exercise the real FastAPI app end-to-end (ASGITransport, not
    a mocked dependency), so every request goes through Depends(get_db) ->
    billing.database.AsyncSessionLocal -> billing.database.engine — a
    DIFFERENT engine object than the one tests/conftest.py's `engine`/
    `session` fixtures create for the unit tests. SQLite's StaticPool
    (used automatically for ':memory:' URLs) keeps one connection alive per
    engine OBJECT, not per URL string, so this module's requests were
    hitting a schema-less database no other fixture in this codebase was
    ever creating. Drop-then-create on every test keeps them isolated from
    each other's data, same as conftest.py's per-test `engine` fixture does
    for the unit tests.
    """
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest.fixture(autouse=True)
def patch_billing_key(monkeypatch):
    monkeypatch.setenv("BILLING_SECRET_KEY", "test-secret")


@pytest.fixture
def client_headers():
    return {"X-Billing-Key": "test-secret"}


@pytest.fixture
def mock_amnezia():
    with patch("billing.services.billing_service.AmneziaClient") as MockClient:
        instance = AsyncMock()
        from integrations.amnezia.schemas import CreateClientResponse, CreatedClient
        instance.create_client.return_value = CreateClientResponse(
            message="OK",
            client=CreatedClient(
                id="integ-client-id",
                config="vpn://integtest",
                protocol="amneziawg",
            ),
        )
        instance.enable_client.return_value = None
        instance.disable_client.return_value = None
        MockClient.return_value = instance
        yield instance


@pytest.mark.asyncio
async def test_health_endpoint():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_stars_payment_endpoint_unauthorized():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/stars",
            json={
                "telegram_id": 123,
                "telegram_payment_charge_id": "abc",
                "total_amount": 100,
            },
        )
    assert resp.status_code == 422  # missing X-Billing-Key header


@pytest.mark.asyncio
async def test_stars_payment_missing_plan(client_headers):
    """Should return 400 if no plan exists in DB."""
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/stars",
            headers=client_headers,
            json={
                "telegram_id": 9991,
                "telegram_payment_charge_id": "no_plan_test",
                "total_amount": 100,
            },
        )
    # Either 400 (ValueError: No active plan) or 500
    assert resp.status_code in (400, 500)


@pytest.mark.asyncio
async def test_manat_request_confirm_flow_end_to_end(client_headers, mock_amnezia):
    """
    Full HTTP round-trip: create a manat request, confirm it as an agent,
    and verify a second agent's attempt on the same (now-resolved) request
    is correctly rejected with 409 — exercising the actual Pydantic
    request/response schemas and exception-to-status-code mapping in the
    routers, not just BillingService directly (already covered by the unit
    tests in tests/unit/test_billing_service.py).
    """
    async with AsyncSessionLocal() as session:
        from models.models import Plan, VpnServer, VpnServerStatus

        plan = Plan(
            name="Integ Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        server = VpnServer(
            name="Integ Server", base_url="http://integ-vpn:4001", api_key="k",
            region="EU", weight=100, status=VpnServerStatus.active,
            max_clients=500, current_clients=0,
        )
        session.add_all([plan, server])
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={
                "telegram_id": 8001,
                "username": "manat_integ_user",
                "plan_id": plan_id,
                "agent_phone_shown": "+993 12 345678",
            },
        )
        assert create_resp.status_code == 200
        body = create_resp.json()
        assert body["agent_phone_shown"] == "+993 12 345678"
        assert body["amount_manat"] == 350.0
        request_id = body["request_id"]

        confirm_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/confirm",
            headers=client_headers,
            json={"agent_id": 9001},
        )
        assert confirm_resp.status_code == 200
        confirm_body = confirm_resp.json()
        assert confirm_body["ok"] is True
        assert "subscription_id" in confirm_body
        assert confirm_body["telegram_id"] == 8001, (
            "bot needs this to notify the payer from the agent's own chat/FSM "
            "session, which has no access to the payer's FSMContext"
        )
        assert confirm_body["status"] == "active"
        assert confirm_body["config_url"], "mock_amnezia should have provisioned a real client"

        # A second agent trying to act on the already-resolved request
        # must get 409, not a silent success or a bare 500.
        second_confirm_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/confirm",
            headers=client_headers,
            json={"agent_id": 9002},
        )
        assert second_confirm_resp.status_code == 409

        reject_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/reject",
            headers=client_headers,
            json={"agent_id": 9003},
        )
        assert reject_resp.status_code == 409


@pytest.mark.asyncio
async def test_manat_reject_flow_end_to_end(client_headers):
    """A rejected request must never produce a subscription — checked via
    the same HTTP path a real "no transfer seen" agent action takes."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ Reject Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={
                "telegram_id": 8002,
                "plan_id": plan_id,
                "agent_phone_shown": "+993 12 999999",
            },
        )
        request_id = create_resp.json()["request_id"]

        reject_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/reject",
            headers=client_headers,
            json={"agent_id": 9004},
        )
        assert reject_resp.status_code == 200
        assert reject_resp.json() == {"ok": True}


@pytest.mark.asyncio
async def test_manat_request_unknown_plan_returns_400(client_headers):
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={
                "telegram_id": 8003,
                "plan_id": 999999,
                "agent_phone_shown": "+993 12 345678",
            },
        )
    assert resp.status_code == 400


@pytest.mark.asyncio
async def test_manat_confirm_unknown_request_returns_404(client_headers):
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/admin/manat/999999/confirm",
            headers=client_headers,
            json={"agent_id": 9001},
        )
    assert resp.status_code == 404
