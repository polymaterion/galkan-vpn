"""
Unit tests for the /broadcast button-line parser (bot/handlers/admin_handlers.py).
Pure function, no DB — each line of input is one keyboard row, "|" separates
buttons within a row, "label - url" per button.
"""
import pytest

from bot.handlers.admin_handlers import ButtonParseError, _parse_broadcast_buttons


def test_empty_input_returns_none():
    assert _parse_broadcast_buttons("") is None
    assert _parse_broadcast_buttons("   \n  \n  ") is None


def test_single_button_single_row():
    kb = _parse_broadcast_buttons("Visit us - https://example.com")
    assert kb is not None
    assert len(kb.inline_keyboard) == 1
    assert len(kb.inline_keyboard[0]) == 1
    btn = kb.inline_keyboard[0][0]
    assert btn.text == "Visit us"
    assert btn.url == "https://example.com"


def test_multiple_lines_become_multiple_rows():
    kb = _parse_broadcast_buttons(
        "First - https://a.com\nSecond - https://b.com\nThird - https://c.com"
    )
    assert len(kb.inline_keyboard) == 3
    assert [row[0].text for row in kb.inline_keyboard] == ["First", "Second", "Third"]


def test_pipe_separated_buttons_share_one_row():
    kb = _parse_broadcast_buttons("Button A - https://a.com | Button B - https://b.com")
    assert len(kb.inline_keyboard) == 1
    assert len(kb.inline_keyboard[0]) == 2
    assert kb.inline_keyboard[0][0].text == "Button A"
    assert kb.inline_keyboard[0][0].url == "https://a.com"
    assert kb.inline_keyboard[0][1].text == "Button B"
    assert kb.inline_keyboard[0][1].url == "https://b.com"


def test_mixed_single_and_paired_rows():
    kb = _parse_broadcast_buttons(
        "Solo - https://solo.com\nLeft - https://l.com | Right - https://r.com"
    )
    assert len(kb.inline_keyboard) == 2
    assert len(kb.inline_keyboard[0]) == 1
    assert len(kb.inline_keyboard[1]) == 2


def test_label_containing_literal_dash_is_not_split_early():
    # rsplit on the LAST " - " means a label like "Buy now - 50% off" (which
    # itself contains " - ") must still resolve to that whole phrase as the
    # label, with only the actual URL split off.
    kb = _parse_broadcast_buttons("Buy now - 50% off - https://shop.example.com")
    btn = kb.inline_keyboard[0][0]
    assert btn.text == "Buy now - 50% off"
    assert btn.url == "https://shop.example.com"


def test_blank_lines_are_skipped():
    kb = _parse_broadcast_buttons("First - https://a.com\n\n\nSecond - https://b.com")
    assert len(kb.inline_keyboard) == 2


@pytest.mark.parametrize(
    "bad_line,expected_reported_line",
    [
        ("No separator here", "No separator here"),
        ("Missing url - ", "Missing url -"),
        (" - https://no-label.com", "- https://no-label.com"),
        ("Bad scheme - ftp://example.com", "Bad scheme - ftp://example.com"),
        ("Bad scheme - example.com", "Bad scheme - example.com"),
        ("Bad scheme - javascript:alert(1)", "Bad scheme - javascript:alert(1)"),
    ],
)
def test_malformed_button_raises_with_line_content(bad_line, expected_reported_line):
    with pytest.raises(ButtonParseError) as exc_info:
        _parse_broadcast_buttons(bad_line)
    # The parser strips each line before storing it on the exception (so an
    # error message shown to the admin doesn't have stray leading/trailing
    # whitespace) — compare against that stripped form, not the raw input.
    assert exc_info.value.line == expected_reported_line
    assert exc_info.value.line_num == 1


def test_error_reports_correct_line_number_in_multiline_input():
    text = "Good - https://a.com\nStill good - https://b.com\nBroken line here"
    with pytest.raises(ButtonParseError) as exc_info:
        _parse_broadcast_buttons(text)
    assert exc_info.value.line_num == 3
    assert exc_info.value.line == "Broken line here"


def test_one_bad_button_in_a_pipe_row_fails_the_whole_row():
    with pytest.raises(ButtonParseError):
        _parse_broadcast_buttons("Good - https://a.com | Bad button no url")


@pytest.mark.parametrize(
    "scheme",
    ["http://example.com", "https://example.com", "tg://resolve?domain=test"],
)
def test_allowed_url_schemes(scheme):
    kb = _parse_broadcast_buttons(f"Label - {scheme}")
    assert kb.inline_keyboard[0][0].url == scheme
